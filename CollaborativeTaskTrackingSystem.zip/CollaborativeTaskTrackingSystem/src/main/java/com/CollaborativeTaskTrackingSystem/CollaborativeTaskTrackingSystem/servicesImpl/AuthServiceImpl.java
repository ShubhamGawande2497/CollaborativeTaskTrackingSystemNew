package com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.servicesImpl;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.services.AuthService;

public class AuthServiceImpl implements AuthService {
    
     @Override
    public String authenticate(String username, String password) {
        return "";
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return null;
    }
    
}
