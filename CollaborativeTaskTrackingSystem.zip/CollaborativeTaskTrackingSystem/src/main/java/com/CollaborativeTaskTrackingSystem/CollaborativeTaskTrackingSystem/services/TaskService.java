package com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.services;

import java.util.List;

import com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.dtos.TaskRequest;
import com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.dtos.TaskResponse;

public interface TaskService {
    public TaskResponse createTask(TaskRequest taskRequest , String createdByEmail);
    public TaskResponse updateTask(String taskId, TaskRequest taskRequest );
    public void deleteTask(String taskId );
    public List<TaskResponse> searchTasks(String keyword);
    public List<TaskResponse> getTasksForUser(String userEmail);
    public List<TaskResponse> getTasksByProject(String projectId);
}
