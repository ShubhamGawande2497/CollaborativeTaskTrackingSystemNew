package com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollaborativeTaskTrackingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollaborativeTaskTrackingSystemApplication.class, args);
	}

}
