package com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.services;


import java.util.List;

import com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.dtos.TeamRequest;
import com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.dtos.TeamResponse;

public interface TeamService {
    public TeamResponse createTeam(TeamRequest request, String createdByEmail);
    public List<TeamResponse> getTeamsForUser(String email);
    public TeamResponse joinTeam(String teamId, String email);
    public void leaveTeam(String teamId, String email);
}
