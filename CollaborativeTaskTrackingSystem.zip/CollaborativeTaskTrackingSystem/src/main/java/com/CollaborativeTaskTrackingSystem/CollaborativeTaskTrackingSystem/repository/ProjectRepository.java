package com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.repository;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;
import com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.entityM.Project;

public interface ProjectRepository extends MongoRepository<Project, String> {

    List<Project> findByTeamTeamId(String teamId);
    List<Project> findByTeamId(String teamId);

}
