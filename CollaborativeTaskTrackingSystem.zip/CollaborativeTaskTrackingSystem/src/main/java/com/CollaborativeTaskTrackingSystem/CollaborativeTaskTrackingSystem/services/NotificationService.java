package com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.services;

import java.util.List;

import com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.entityM.Notification;

public interface NotificationService {
    
    Notification createNotification(String userId, String message);
    List<Notification> getNotifications(String userId);
}
