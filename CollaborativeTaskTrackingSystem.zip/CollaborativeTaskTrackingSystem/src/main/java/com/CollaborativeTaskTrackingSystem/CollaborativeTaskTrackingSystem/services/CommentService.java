package com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.services;


import java.util.List;

import com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.dtos.CommentRequest;
import com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.dtos.CommentResponse;

public interface CommentService {
     CommentResponse addComment(CommentRequest request, String userEmail);
    List<CommentResponse> getCommentsByTask(String taskId);
    void deleteComment(String taskId, String commentId, String userEmail);
}
