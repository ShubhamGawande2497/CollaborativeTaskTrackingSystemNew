package com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.services;

import java.util.List;
import java.io.IOException;
import org.springframework.web.multipart.MultipartFile;
import com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.dtos.AttachmentResponse;

public interface AttachmentService {
    AttachmentResponse uploadAttachment(String taskId, MultipartFile file, String uploadedBy) throws IOException, IOException;
    List<AttachmentResponse> getAttachmentsByTask(String taskId);
    void deleteAttachment(String taskId, String attachmentId, String userEmail);
    
}
