package com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.services;

import java.util.List;

import com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.dtos.ProjectRequest;
import com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.dtos.ProjectResponse;

public interface ProjectService {
    public ProjectResponse createProject(ProjectRequest request, String createdByEmail);
    public List<ProjectResponse> getProjectsByTeam(String teamId);
    public ProjectResponse getProjectById(String projectId);
    public ProjectResponse updateProject(String projectId, ProjectRequest request);
    public void deleteProject(String projectId);
}
