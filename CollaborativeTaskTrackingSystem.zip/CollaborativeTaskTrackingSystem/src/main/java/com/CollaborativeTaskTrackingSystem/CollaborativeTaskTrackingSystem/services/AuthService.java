package com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.services;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface AuthService  extends UserDetailsService {
     String authenticate(String username, String password);
}
