package com.CollaborativeTaskTrackingSystem.CollaborativeTaskTrackingSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/cpmments")
public class CommentController {

    @Autowired 
    private CommentService commentService;

    @PostMapping
    public ResponseEntity<CommentResponse> addComment(@Valid @RequestBody CommentRequest request, Authentication auth) {
        return ResponseEntity.ok(commentService.addComment(request, auth.getName()));
    }

    @GetMapping("/{taskId}")
    public ResponseEntity<List<CommentResponse>> getComments(@PathVariable String taskId) {
        return ResponseEntity.ok(commentService.getCommentsByTask(taskId));
    }

    @DeleteMapping("/{taskId}/{commentId}")
    public ResponseEntity<String> deleteComment(@PathVariable String taskId, @PathVariable String commentId, Authentication auth) {
        commentService.deleteComment(taskId, commentId, auth.getName());
        return ResponseEntity.ok("Comment deleted successfully");
    }
    
}



